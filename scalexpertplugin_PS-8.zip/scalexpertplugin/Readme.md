# scalexpert-prestashop
Scalexpert plugins for Prestashop 8

Version : 1.1.0
