# Scalexpert plugins for Prestashop 8

Version : 1.5.0
