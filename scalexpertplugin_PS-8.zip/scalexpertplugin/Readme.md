# Scalexpert plugins for Prestashop 8

Version : 1.3.2
