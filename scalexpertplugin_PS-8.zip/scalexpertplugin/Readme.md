# Scalexpert plugins for Prestashop 8

Version : 1.2.6
