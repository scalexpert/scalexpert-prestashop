Change Log:

- delivery of version 1.0.0 of plugin prestashop 8
- content: e-financing solutions split payment & long term credit
