$(document).ready(function () {
    new window.prestashop.component.ChoiceTree('.js-choice-tree-container');
});