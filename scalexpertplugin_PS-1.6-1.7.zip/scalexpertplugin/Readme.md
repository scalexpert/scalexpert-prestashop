# scalexpert-prestashop
Scalexpert plugins for Prestashop 1.6, 1.7

Version : 1.1.0
