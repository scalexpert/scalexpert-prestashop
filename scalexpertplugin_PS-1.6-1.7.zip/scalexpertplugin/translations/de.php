<?php
/**
 * Copyright © Scalexpert.
 * This file is part of Scalexpert plugin for PrestaShop. See COPYING.md for license details.
 *
 * @author    Scalexpert (https://scalexpert.societegenerale.com/)
 * @copyright Scalexpert
 * @license   https://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 */


global $_MODULE;
$_MODULE = array();
$_MODULE['<{scalexpertplugin}prestashop>scalexpertplugin_495302df11cf5704383417c300d38962'] = 'Bitte geben Sie eine gültige Telefonnummer an, um diese Zahlungsmethode auszuwählen';
