Change Log:

- delivery of version 1.0.0 of plugin prestashop 1.6, 1.7
- content: e-financing solutions split payment & long term credit
